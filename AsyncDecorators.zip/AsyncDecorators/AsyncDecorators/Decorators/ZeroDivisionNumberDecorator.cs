﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service;

namespace AsyncDecorators.Decorators
{
    public class ZeroDivisionNumberDecorator : NumberServiceDecorator
    {
        public ZeroDivisionNumberDecorator( INumberService decorated )
            : base( decorated )
        {
        }

        public override Task<int> Divide( int dividend, int divider )
        {
            if( divider == 0 )
            {
                throw new DivideByZeroException( "Decorator exception: DivideByZero" );
            }
            return base.Divide( dividend, divider );
        }
    }
}
