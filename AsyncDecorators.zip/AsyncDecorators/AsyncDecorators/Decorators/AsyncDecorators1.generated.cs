﻿/// <summary>
/// Klasy dekoratorów wygenerowanych na podstawie interfejsów oznaczonych atrybutem o nazwie
/// "GenerateDecorator"
/// Dekorator przyjmuje dwa parametry w konstruktorze: pierwszy - obiekt dekorowany,
/// drugi opcjonalny - strategia wykonania metod before i after
/// Dekorator zawiera pełną implementacje interfejsu według stałego szablonu:
/// utworzenie kontekstu wywołania funkcji, wykonanie before, wykonanie metody dekorowanej
/// i wykonanie after
/// Wszystkie funkcje są wirtualne, więc można je przesłoniać dostosowując dekoracje w inny sposób
/// </summary>

using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace AsyncDecorators.Decorators
{
    public class NumberServiceDecorator : Service.INumberService
    {
        private Service.INumberService _decorated = null;
        private IDecoratorStrategy _strategy = null;

        public NumberServiceDecorator( Service.INumberService service, IDecoratorStrategy strategy = null )
        {
            _decorated = service;
            _strategy = strategy;
        }

        public virtual async System.Threading.Tasks.Task<int> Divide( int dividend, int divider )
        {
            var context = DecoratorContext.OfFunction<System.Threading.Tasks.Task<int>>( "Divide" )
                .WithParameters( dividend, divider )
                .WithAttributes();
            await BeforeAsync( context );
            if( context.RunDecorated )
            {
                context.ReturnValue = await _decorated.Divide( dividend, divider );
            }
            if( context.RunAfter )
            {
                await AfterAsync( context );
            }
            return (int)context.ReturnValue;
        }

#pragma warning disable 1998
        protected virtual async Task BeforeAsync( IBeforeDecorationContext context )
        {
            if( _strategy != null )
            {
                await _strategy.BeforeAsync( context );
            }
        }

        protected virtual async Task AfterAsync( IAfterDecorationContext context )
        {
            if( _strategy != null )
            {
                await _strategy.AfterAsync( context );
            }
        }
#pragma warning restore 1998

        protected virtual void Before( IBeforeDecorationContext context )
        {
            if( _strategy != null )
            {
                _strategy.Before( context );
            }
        }

        protected virtual void After( IAfterDecorationContext context )
        {
            if( _strategy != null )
            {
                _strategy.After( context );
            }
        }
    }

    #region Decorator Context
    /// <summary>
    /// Kontekst wywołania funkcji
    /// Obejmuje dwa osobne interfejsy dla before i dla after
    /// Zawiera podstawowe informacje o funkcji, parametry, a także wartości sterujące wykonaniem
    /// RunDecorated ustawione na false spowoduje ominięcie wywołania funkcji dekorowanej
    /// </summary>

    // Interfejs kontekstu przekazywany do funkcji after
    public interface IAfterDecorationContext
    {
        IEnumerable<object> Parameters
        {
            get;
        }
        
        IEnumerable<string> Attributes
        {
            get;
        }

        object ReturnValue
        {
            get;
            set;
        }

        Type ReturnType
        {
            get;
        }

        string DecoratedFunctionName
        {
            get;
        }
    }

    // Interfejs kontekstu przekazywany do funkcji before (rozszerzenie after)
    public interface IBeforeDecorationContext : IAfterDecorationContext
    {
        bool RunDecorated
        {
            get;
            set;
        }

        bool RunAfter
        {
            get;
            set;
        }
    }

    // Kontekst wywołania funkcji w dekoratorze
    public class DecoratorContext : IBeforeDecorationContext, IAfterDecorationContext
    {
        private List<object> _parameters = new List<object>();
        private List<string> _attributes = new List<string>();

        protected DecoratorContext( string functionName, Type type )
        {
            RunDecorated = true;
            RunAfter = true;
            ReturnValue = null;
            ReturnType = type;
            DecoratedFunctionName = functionName;
        }

        public static DecoratorContext OfFunction<T>( string functionName )
        {
            return DecoratorContext.OfFunction( functionName, typeof( T ) );
        }

        public static DecoratorContext OfFunction( string functionName, Type returnType )
        {
            return new DecoratorContext( functionName, returnType );
        }

        public IEnumerable<object> Parameters
        {
            get
            {
                return _parameters;
            }
        }

        public IEnumerable<string> Attributes
        {
            get
            {
                return _attributes;
            }
        }

        public string DecoratedFunctionName
        {
            get;
            protected set;
        }

        public bool RunDecorated
        {
            get;
            set;
        }

        public bool RunAfter
        {
            get;
            set;
        }

        public object ReturnValue
        {
            get;
            set;
        }

        public Type ReturnType
        {
            get;
            protected set;
        }

        public DecoratorContext With( object parameter )
        {
            _parameters.Add( parameter );
            return this;
        }

        public DecoratorContext WithParameters( params object[] parameters )
        {
            if( parameters != null && parameters.Any() )
            {
                _parameters.AddRange( parameters );
            }
            return this;
        }

        public DecoratorContext WithAttributes( params string[] attributes )
        {
            if( attributes != null && attributes.Any() )
            {
                _attributes.AddRange( attributes );
            }
            return this;
        }
    }
    #endregion

    #region Decorator Strategy
    /// <summary>
    /// Interfejs strategii do udekorowanych funkcji
    /// Dekorator zakłada jedną strategie dla wszystkich wywołań funkcji
    /// </summary>
    public interface IDecoratorStrategy
    {
        Task BeforeAsync( IBeforeDecorationContext context );
        Task AfterAsync( IAfterDecorationContext context );
        void Before( IBeforeDecorationContext context );
        void After( IAfterDecorationContext context );
    }
    #endregion
}
