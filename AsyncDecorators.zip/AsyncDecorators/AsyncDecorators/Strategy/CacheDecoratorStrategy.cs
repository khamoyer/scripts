﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AsyncDecorators.Decorators;

namespace AsyncDecorators.Strategy
{
    //use raw generated decorator with this strategy in constructor
    public class CacheDecoratorStrategy : IDecoratorStrategy
    {
        public Task BeforeAsync( IBeforeDecorationContext context )
        {
            throw new NotImplementedException();
        }

        public Task AfterAsync( IAfterDecorationContext context )
        {
            // store in cache context.ReturnValue
            throw new NotImplementedException();
        }

        public void Before( IBeforeDecorationContext context )
        {
            throw new NotImplementedException();
        }

        public void After( IAfterDecorationContext context )
        {
            throw new NotImplementedException();
        }
    }
}
