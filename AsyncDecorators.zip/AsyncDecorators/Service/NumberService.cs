﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class NumberService : INumberService
    {
        public Task<int> Divide( int dividend, int divider )
        {
            return Task.FromResult( dividend / divider );
        }
    }
}
