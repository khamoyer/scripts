﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    [GenerateDecorator]
    public interface INumberService
    {
        Task<int> Divide( int dividend, int divider );
    }
}
